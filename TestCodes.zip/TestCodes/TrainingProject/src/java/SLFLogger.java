///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
///**
// *
// * @author test
// */
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public class SLFLogger {
//
//    private final static Logger slf4jLogger = LoggerFactory.getLogger(SLFLogger.class);
//
//    /**
//     * Print hello in log.
//     *
//     * @param name
//     */
//    public static void printOut(Object name) {
//        slf4jLogger.info(name.toString());
//    }
//    public static void printError(String errorStr) {
//        slf4jLogger.error(errorStr);
//        
//    }
//
//    /**
//     * @param args
//     */
////    public static void main(String[] args) {
////        SLFLogger slf4jHello = new SLFLogger();
////        slf4jHello.printOut("srccodes.com");
////    }
//}
