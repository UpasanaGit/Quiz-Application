/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author test
 */
public class NewClass {

//    private int a = 10;
//    public static int aP = 1000;
//
//    public static void main(String[] args) {
//        int b = 100;
//
////        System.out.println(a);
//
//        System.out.println(b);
//        new NewClass().testPrivate(200);
//    }
//
//    public void testPrivate(int testA) {
//        System.out.println(a);
//        a=testA;
//        System.out.println(aP);
//        System.out.println(a);
//    }
    public static void main(String[] args) {
        String response = " perfiosTransactionId=3HEM1537851182231&clientTransactionId=CAOD-00000000284-PRO&status=COMPLETED&errorCode=E_NO_ERROR&errorMessage=Successfully+completed.";

        String requestArr[] = response.split("&");
        String idStatus = requestArr[2];
        String perfiosTxnId = requestArr[0];
        String status = idStatus.split("=")[1];
        System.out.println("callback status return ---" + status);
        System.out.println(perfiosTxnId.split("=")[1]);
    }
}
