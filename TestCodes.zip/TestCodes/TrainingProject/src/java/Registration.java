
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author test
 */
public class Registration {

    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        String id = "01";
        String sal = "Dear";
        String person = "Poojan";
        String gender = "Female";
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.24:1521:orcl", "servostreams104", "system123#");
//        Connection conn = DriverManager.getConnection("oracle:jdbc:/192.168.1.24:1521/Servostreams", "servostreams104", "system123#");
        String query = "Insert into CAOD_ENTITYDATA(PINSTID,SALUTATION,PERSON,GENDER) values(?,?,?,?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, id);
        ps.setString(2, sal);
        ps.setString(3, person);
        ps.setString(4, gender);
        ps.executeUpdate();
        System.out.println("Successfully Inserted");
        

    }

}
