//
//
///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
///**
// *
// * @author test
// */
//public class PDFModify {
//
//    public static void main(String[] args) {
//        try {
//            String test = "Hapur";
//            // writing the FDF file
//            FdfWriter fdf = new FdfWriter();
//            fdf.setFieldAsString("IPStamp", "192.168.1.219");
//            fdf.setFieldAsString("AppFormNo", "BIL0000000245");
//            fdf.setFieldAsString("Prefix", "Ms");
//            fdf.setFieldAsString("FirstName", "Upasana");
//            fdf.setFieldAsString("Gender_M", "Yes");
//            fdf.setFieldAsString("City", test);
//            fdf.setFile(PdfTestBase.RESOURCES_DIR + "BIL_Final.pdf");
//            fdf.writeTo(PdfTestBase.getOutputStream("BIL_Final.fdf"));
//
//            // merging the FDF file
//            PdfReader pdfreader = new PdfReader(PdfTestBase.RESOURCES_DIR + "BIL_Final.pdf");
//            PdfStamper stamp = new PdfStamper(pdfreader, PdfTestBase.getOutputStream("BIL_Final_fdf.pdf"));
//            FdfReader fdfreader = new FdfReader(PdfTestBase.OUTPUT_DIR + "BIL_Final.fdf");
//            AcroFields form = stamp.getAcroFields();
//            form.setFields(fdfreader);
//            stamp.close();
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//    }
//}
