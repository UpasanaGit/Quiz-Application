


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author test
 */
public class TestClass {

    public static void main(String[] args) {
//        DateFormat df1 = new SimpleDateFormat("MM-dd-yyyy");
//        Calendar calobj = Calendar.getInstance();
//        SLFLogger.printOut(calobj.get(Calendar.DAY_OF_MONTH));
//        int daysInMonth = calobj.getActualMaximum(Calendar.DAY_OF_MONTH);
//        SLFLogger.printOut("daysInMonth = " + daysInMonth);
//        int leftDaysInMonth = daysInMonth - calobj.get(Calendar.DAY_OF_MONTH);
//        SLFLogger.printOut("leftDaysInMonth = " + leftDaysInMonth);
//
//        if (leftDaysInMonth + 10 < 21) {
//            calobj.set(calobj.get(Calendar.YEAR), (calobj.get(Calendar.MONTH) + 2), 10);
//        } else {
//            calobj.set(calobj.get(Calendar.YEAR), (calobj.get(Calendar.MONTH) + 1), 10);
//        }
//        SLFLogger.printOut("EMI Start Date---" + df1.format(calobj.getTime()));
//
//        calobj.set(Calendar.MONTH, (calobj.get(Calendar.MONTH) + 29));
//        SLFLogger.printOut("EMI End Date---" + df1.format(calobj.getTime()));

//        new NewClass().testPrivate(500);
    }

}
