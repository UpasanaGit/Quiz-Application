/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testRest;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * REST Web Service
 *
 * @author test
 */
@Path("/TestRest")
public class TestREST {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of HelloWorld
     */
    public TestREST() {
    }

    /**
     * Retrieves representation of an instance of HelloWorldResource.HelloWorld
     *
     * @return an instance of java.lang.String
     */
    @Path("/first")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getHtml() {
        return "<html><body><h1>Hello World!</body></h1></html>";
    }

    @Path("/second")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getData() {
        return "<html><body><h1>Welcome to the another World!</body></h1></html>";
    }

    /**
     * PUT method for updating or creating an instance of HelloWorld
     *
     * @param content representation for the resource
     */
    @Path("/hitCheck")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String putHtml(String content) throws JSONException {
        JSONObject json = new JSONObject(content);
        if (json.get("HitNum").equals("1")) {
            return "<html><body><h1>Hello World!</body></h1></html>";
        } else if (json.get("HitNum").equals("2")) {
            return "<html><body><h1>Welcome to the another World!</body></h1></html>";
        } else {
            return "Invalid Request!";
        }
    }

    @Path("/uploadDoc")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public String uploadDoc(@FormDataParam("file") InputStream fileIOS,@FormDataParam("fileName") String fileName) {
        String path = "";
        System.out.println("fileIOS---" + fileIOS);
        try {
//            path = "C:\\Users\\test\\Documents\\NetBeansProjects\\test.jpg";
            path = "C:\\Users\\test\\Documents\\NetBeansProjects\\" + fileName;
            final OutputStream out = new FileOutputStream(new File(path));
            int read = 0;
            byte[] bytes = new byte[1024];
            while ((read = fileIOS.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "File uploaded at " + path + " !";
    }

}
