/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customexception;

import interfacepkg.ExceptionCode;

/**
 *
 * @author test
 */
public class Test {

    public static void displayMyMessage() throws MyCustomException {
        throw new MyCustomException(ExceptionCode.INVALID_REQUEST);
    }

    public static void main(String[] args) {
// Usage :
        try {
            displayMyMessage();
        } catch (MyCustomException e) {
            e.printStackTrace();
// System.out.println(e.getErrorMsg());
            switch (e.getErrorCode()) {
                case ExceptionCode.CODE_402:
                    System.out.println(e.getErrorMsg());
                    break;
                case ExceptionCode.CODE_403:
                    System.out.println(e.getErrorMsg());
                    break;
                case ExceptionCode.CODE_200:
                    System.out.println(e.getErrorMsg());
                    break;
                default:
                    break;
            }

        }
    }
}
