/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacepkg;

import static interfacepkg.ErroCodeConstant.CODE_200;
import static interfacepkg.ErroCodeConstant.CODE_402;
import static interfacepkg.ErroCodeConstant.CODE_403;

/**
 *
 * @author test
 */
public enum ExceptionCode implements ErroCodeConstant {

    ACTIVE_USER_FOUND(CODE_200, "Active user found"),
    INVALID_REQUEST(CODE_402, "The request is invalid"),
    INACTIVE_USER(CODE_403, "Inactive user");

    private final int id;
    private final String msg;

    ExceptionCode(int id, String msg) {
        this.id = id;
        this.msg = msg;
    }

    public int getId() {
        return this.id;
    }

    public String getMsg() {
        return this.msg;
    }
}
