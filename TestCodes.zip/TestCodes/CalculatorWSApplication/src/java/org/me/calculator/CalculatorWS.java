/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.calculator;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.jws.WebResult;

/**
 *
 * @author test
 */
@WebService(serviceName = "Calculator")
@Stateless()
public class CalculatorWS {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    @WebResult(name = "Output")
    public String hello(@WebParam(name = "name") String txt, @WebParam(name = "token", header = true) String session) {
        if (!txt.trim().equals("")) {
            return "Hello " + txt.trim() + " !";
        } else {
//            return session;
            return "Name missing";
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "add")
    @WebResult(name = "Output")
    public int add(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        if (b != 0 && a != 0) {
            int k = a + b;
            return k;
        } else {
            return 0;
        }
    }

    @WebMethod(operationName = "subtract")
    @WebResult(name = "Output")
    public String subtract(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        if (b != 0 && a != 0 && a >= b) {
            int k = a - b;
            return String.valueOf(k);
        } else {
            return "Invaid Request.";
        }
    }
}
