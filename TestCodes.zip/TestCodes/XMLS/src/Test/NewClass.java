/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author test
 */
public class NewClass {

    public static void main(String[] args) throws ParseException {
//        String emiStartDate = "", emiEndDate = "", tenure = "12";
//        DateFormat df = new SimpleDateFormat("HH:mm:ss");
//        DateFormat df1 = new SimpleDateFormat("dd-MM-yyyy");
//        Calendar calobj = Calendar.getInstance();
//
//        int daysInMonth = calobj.getActualMaximum(Calendar.DAY_OF_MONTH);
//        int todayDate = calobj.get(Calendar.DAY_OF_MONTH);
//        System.out.println("calobj.get(Calendar.DAY_OF_MONTH)---" + calobj.get(Calendar.DAY_OF_MONTH));
//        int leftDaysInMonth = daysInMonth - calobj.get(Calendar.DAY_OF_MONTH);
//        System.out.println("daysInMonth--" + daysInMonth + "----leftDaysInMonth---" + leftDaysInMonth);
//        if (todayDate >= 1 && todayDate <= 10) {
//            System.out.println("date is between 1 and 10.");
//            calobj.set(calobj.get(Calendar.YEAR), (calobj.get(Calendar.MONTH) + 1), 5);
//        } else if (todayDate >= 11 && todayDate <= 15) {
//            System.out.println("date is between 11 and 15.");
//            calobj.set(calobj.get(Calendar.YEAR), (calobj.get(Calendar.MONTH) + 1), 10);
//        } else {
//            System.out.println("date is between 16 and 31.");
//            calobj.set(calobj.get(Calendar.YEAR), (calobj.get(Calendar.MONTH) + 2), 5);
//        }
//       
//        emiStartDate = df1.format(calobj.getTime());
//        calobj.set(Calendar.MONTH, (calobj.get(Calendar.MONTH) + (Integer.parseInt(tenure) - 1)));
//        emiEndDate = df1.format(calobj.getTime());
//        System.out.println("emiStartDate----" + emiStartDate + "----emiEndDate----" + emiEndDate);
        String account = "034205007981";
        String solId = account.substring(0, 4);
        System.out.println(solId);

        String dob = "12-09-2018";
        SimpleDateFormat inSDF = new SimpleDateFormat("DD-MM-YYYY");
        java.util.Date date = inSDF.parse(dob);
        java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
        System.out.println("sqlStartDate-=--" + sqlStartDate);
    }
}
