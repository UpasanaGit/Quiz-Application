/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

/**
 *
 * @author test
 */
public class Magic {
    public static void main(String[] args) {
        //commented section
        // \u000d System.out.println("Magical text----");
    }
}
