/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import java.io.OutputStreamWriter;

/**
 *
 * @author test
 */
public class RupeeReplace {

    public static void main(String[] args) throws Exception {
        String rupeeStr = "Coins of denomination of ₹1, ₹2, ₹5 and ₹10 with the new rupee symbol have been put into circulation. As of January 2012, the new Indian rupee sign has been incorporated in the currency notes in the denominations of ₹10, ₹100, ₹500 and ₹2000 and as of 12 April 2012 this was extended to denominations of ₹20 and ₹50.";
        System.out.println(rupeeStr);
    }
}
