/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.promoxml;

import javax.xml.bind.annotation.XmlRootElement;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Path;
import org.simpleframework.xml.Root;

/**
 *
 * @author SERVOSYS-019
 */
@Root(name = "XML", strict = false)
public class PromoResponse {

    @Element(name = "MessageType", required = false)
    private String MessageType;

    @Element(name = "ProcCode", required = false)
    private String ProcCode;

    @Element(name = "ActCode", required = false)
    private String ActCode;

    @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/Header")
    @Element(name = "MessageID", required = false)
    private String MessageID = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/Header")
    @Element(name = "CorrelationID", required = false)
    private String CorrelationID = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/Result")
    @Element(name = "Code", required = false)
    private String Code = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/ResponseData/Numbers")
    @Element(name = "CustomerNumber", required = false)
    private String CustomerNumber = "";
   @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/ResponseData/Numbers")
    @Element(name = "AccountNumber", required = false)
    private String AccountNumber = "";
      @Path("SOAPMessage/soap:Envelope/soap:Body/LoadBridgeXmlResponse/LoadBridgeXmlResult/ResponseData/Numbers")
    @Element(name = "CardNumber", required = false)
    private String CardNumber = "";
    public String getMessageID() {
        return MessageID;
    }

    public void setMessageID(String MessageID) {
        this.MessageID = MessageID;
    }

    public String getCorrelationID() {
        return CorrelationID;
    }

    public void setCorrelationID(String CorrelationID) {
        this.CorrelationID = CorrelationID;
    }

    public String getMessageType() {
        return MessageType;
    }

    public void setMessageType(String MessageType) {
        this.MessageType = MessageType;
    }

    public String getProcCode() {
        return ProcCode;
    }

    public void setProcCode(String ProcCode) {
        this.ProcCode = ProcCode;
    }

    public String getActCode() {
        return ActCode;
    }

    public void setActCode(String ActCode) {
        this.ActCode = ActCode;
    }

}
