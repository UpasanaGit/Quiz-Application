/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.promoxml;

import com.google.gson.GsonBuilder;
import com.parse.promoxml.PromoResponse;
import com.parse.promoxml.PromoResponse1;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

/**
 *
 * @author SERVOSYS-019
 */
public class PromoResponseXml {

    public static void main(String[] args) throws Exception {
//        // TODO code application logic here
        String textToParse = readTextFile("C:\\Users\\test\\Documents\\Shared\\XML\\PromoResponse.xml");
        Serializer serializer = new Persister();
        PromoResponse xMLRoot = serializer.read(PromoResponse.class, textToParse);

        System.out.println("xmlRoot :: " + new GsonBuilder().setPrettyPrinting().create().toJson(xMLRoot));
        
        String textToParse1 = readTextFile("C:\\Users\\test\\Documents\\Shared\\XML\\PromoResponse1.xml");
        PromoResponse1 xMLRoot1 = serializer.read(PromoResponse1.class, textToParse1);

        System.out.println("xmlRoot :: " + new GsonBuilder().setPrettyPrinting().create().toJson(xMLRoot1));
    }

    public static String readTextFile(String path) {
//         String textToSend="";
        try {
            File file = new File(path);
            InputStream inputStream = new FileInputStream(file);

            InputStreamReader isw = new InputStreamReader(inputStream);
            char[] buffer = new char[8192];
            StringBuilder serverResult = new StringBuilder();
            int length = 0;
            while (length != -1) {
                length = isw.read(buffer);
                if (length > -1) {
                    char[] tmp = java.util.Arrays.copyOf(buffer, length);
                    serverResult.append(tmp);
                }
            }

            //  System.out.println("serverResult : " + serverResult.toString().replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "").trim());
            return serverResult.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}
