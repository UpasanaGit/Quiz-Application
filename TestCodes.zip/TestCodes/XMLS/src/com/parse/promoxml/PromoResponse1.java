package com.parse.promoxml;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Path;
import org.simpleframework.xml.Root;

@Root(name = "XML", strict = false)
public class PromoResponse1 {

    @Element(name = "MessageType", required = false)
    private String MessageType = "";
    @Element(name = "ProcCode", required = false)
    private String ProcCode = "";
    @Element(name = "ActCode", required = false)
    private String ActCode = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/AcquireTicketResponse/AcquireTicketResult/Header")
    @Element(name = "MessageID", required = false)
    private String MessageID = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/AcquireTicketResponse/AcquireTicketResult/Header")
    @Element(name = "CorrelationID", required = false)
    private String CorrelationID = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/AcquireTicketResponse/AcquireTicketResult/Result")
    @Element(name = "Code", required = false)
    private String Code = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/AcquireTicketResponse/AcquireTicketResult")
    @Element(name = "Ticket", required = false)
    private String Ticket = "";
    @Path("SOAPMessage/soap:Envelope/soap:Body/AcquireTicketResponse/AcquireTicketResult")
    @Element(name = "InstitutionID", required = false)
    private String InstitutionID = "";

    public String getMessageType() {
        return MessageType;
    }

    public void setMessageType(String MessageType) {
        this.MessageType = MessageType;
    }

    public String getProcCode() {
        return ProcCode;
    }

    public void setProcCode(String ProcCode) {
        this.ProcCode = ProcCode;
    }

    public String getActCode() {
        return ActCode;
    }

    public void setActCode(String ActCode) {
        this.ActCode = ActCode;
    }

    public String getMessageID() {
        return MessageID;
    }

    public void setMessageID(String MessageID) {
        this.MessageID = MessageID;
    }

    public String getCorrelationID() {
        return CorrelationID;
    }

    public void setCorrelationID(String CorrelationID) {
        this.CorrelationID = CorrelationID;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String Code) {
        this.Code = Code;
    }

    public String getTicket() {
        return Ticket;
    }

    public void setTicket(String Ticket) {
        this.Ticket = Ticket;
    }

    public String getInstitutionID() {
        return InstitutionID;
    }

    public void setInstitutionID(String InstitutionID) {
        this.InstitutionID = InstitutionID;
    }

//    @Override
//    public String toString() {
//        return super.toString(); //To change body of generated methods, choose Tools | Templates.
//    }
//      
}
