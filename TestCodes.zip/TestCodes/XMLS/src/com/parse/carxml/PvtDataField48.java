/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import java.io.Serializable;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author test
 */
@Root(name = "PvtDataField48", strict = false)
public class PvtDataField48  implements Serializable{
    
    @Element(name = "UserID", required = false)
    private String UserID="";
    @Element(name = "ActiveCustId", required = false)
    private String ActiveCustId="";
    @Element(name = "ActiveFSID", required = false)
    private String ActiveFSID="";
    @Element(name = "AuthNum", required = false)
    private String AuthNum="";
    @Element(name = "RelNum", required = false)
    private String RelNum="";
    @Element(name = "CustName", required = false)
    private String CustName="";
    @Element(name = "DOB", required = false)
    private String DOB="";
    @Element(name = "TPINStat", required = false)
    private String TPINStat="";
    @Element(name = "CustType", required = false)
    private String CustType="";
    @Element(name = "LastAccCC", required = false)
    private String LastAccCC="";
    @Element(name = "LastAccInf", required = false)
    private String LastAccInf="";
    @Element(name = "CrossSellMsg", required = false)
    private String CrossSellMsg="";
    @Element(name = "AadhaarNo", required = false)
    private String AadhaarNo="";
    @Element(name = "AadhaarFlag", required = false)
    private String AadhaarFlag="";
    @Element(name = "AadhaarAccNum", required = false)
    private String AadhaarAccNum="";

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public String getActiveCustId() {
        return ActiveCustId;
    }

    public void setActiveCustId(String ActiveCustId) {
        this.ActiveCustId = ActiveCustId;
    }

    public String getActiveFSID() {
        return ActiveFSID;
    }

    public void setActiveFSID(String ActiveFSID) {
        this.ActiveFSID = ActiveFSID;
    }

    public String getAuthNum() {
        return AuthNum;
    }

    public void setAuthNum(String AuthNum) {
        this.AuthNum = AuthNum;
    }

    public String getRelNum() {
        return RelNum;
    }

    public void setRelNum(String RelNum) {
        this.RelNum = RelNum;
    }

    public String getCustName() {
        return CustName;
    }

    public void setCustName(String CustName) {
        this.CustName = CustName;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getTPINStat() {
        return TPINStat;
    }

    public void setTPINStat(String TPINStat) {
        this.TPINStat = TPINStat;
    }

    public String getCustType() {
        return CustType;
    }

    public void setCustType(String CustType) {
        this.CustType = CustType;
    }

    public String getLastAccCC() {
        return LastAccCC;
    }

    public void setLastAccCC(String LastAccCC) {
        this.LastAccCC = LastAccCC;
    }

    public String getLastAccInf() {
        return LastAccInf;
    }

    public void setLastAccInf(String LastAccInf) {
        this.LastAccInf = LastAccInf;
    }

    public String getCrossSellMsg() {
        return CrossSellMsg;
    }

    public void setCrossSellMsg(String CrossSellMsg) {
        this.CrossSellMsg = CrossSellMsg;
    }

    public String getAadhaarNo() {
        return AadhaarNo;
    }

    public void setAadhaarNo(String AadhaarNo) {
        this.AadhaarNo = AadhaarNo;
    }

    public String getAadhaarFlag() {
        return AadhaarFlag;
    }

    public void setAadhaarFlag(String AadhaarFlag) {
        this.AadhaarFlag = AadhaarFlag;
    }

    public String getAadhaarAccNum() {
        return AadhaarAccNum;
    }

    public void setAadhaarAccNum(String AadhaarAccNum) {
        this.AadhaarAccNum = AadhaarAccNum;
    }
    
    
}
