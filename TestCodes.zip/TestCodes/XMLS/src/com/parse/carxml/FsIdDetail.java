/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import java.io.Serializable;
import java.util.List;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author test
 */
@Root(name = "FsIdDetail", strict = false)
public class FsIdDetail  implements Serializable{

    @Element(name = "FsId", required = false)
    private String FsId = "";
    @Element(name = "NumOfAccounts", required = false)
    private String NumOfAccounts = "";
    @ElementList(entry = "AccountDetails", inline = true, required = false)
    List<AccountDetail> AccountDetails;

    public String getFsId() {
        return FsId;
    }

    public void setFsId(String FsId) {
        this.FsId = FsId;
    }

    public String getNumOfAccounts() {
        return NumOfAccounts;
    }

    public void setNumOfAccounts(String NumOfAccounts) {
        this.NumOfAccounts = NumOfAccounts;
    }

    public List<AccountDetail> getAccountDetails() {
        return AccountDetails;
    }

    public void setAccountDetails(List<AccountDetail> AccountDetails) {
        this.AccountDetails = AccountDetails;
    }

}
