package com.parse.carxml;

import java.io.Serializable;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Path;
import org.simpleframework.xml.Root;

@Root(name = "XML", strict = false)
public class CarResponse  implements Serializable{

    @Element(name = "MessageType", required = false)
    private String MessageType = "";
    @Element(name = "CustID", required = false)
    private String CustID = "";
    @Element(name = "ProcCode", required = false)
    private String ProcCode = "";
    @Element(name = "STAN", required = false)
    private String STAN = "";
    @Element(name = "LocalTxnDtTime", required = false)
    private String LocalTxnDtTime = "";
    @Element(name = "ActCode", required = false)
    private String ActCode = "";
    @Element(name = "TxnDestnCode", required = false)
    private String TxnDestnCode = "";
    @Element(name = "TxnOrigCode", required = false)
    private String TxnOrigCode = "";
    @Element(name = "DeliveryChannelCtrlID", required = false)
    private String DeliveryChannelCtrlID = "";
    @Element(name = "PvtDataField48", required = false)
    PvtDataField48 PvtDataField48;
    @Element(name = "PvtDataField125", required = false)
    PvtDataField125 PvtDataField125;
    @Element(name = "PvtDataField126", required = false)
    PvtDataField126 PvtDataField126;
    @Element(name = "PvtDataField127", required = false)
    PvtDataField127 PvtDataField127;

    public String getMessageType() {
        return MessageType;
    }

    public void setMessageType(String MessageType) {
        this.MessageType = MessageType;
    }

    public String getCustID() {
        return CustID;
    }

    public void setCustID(String CustID) {
        this.CustID = CustID;
    }

    public String getProcCode() {
        return ProcCode;
    }

    public void setProcCode(String ProcCode) {
        this.ProcCode = ProcCode;
    }

    public String getSTAN() {
        return STAN;
    }

    public void setSTAN(String STAN) {
        this.STAN = STAN;
    }

    public String getLocalTxnDtTime() {
        return LocalTxnDtTime;
    }

    public void setLocalTxnDtTime(String LocalTxnDtTime) {
        this.LocalTxnDtTime = LocalTxnDtTime;
    }

    public String getActCode() {
        return ActCode;
    }

    public void setActCode(String ActCode) {
        this.ActCode = ActCode;
    }

    public String getTxnDestnCode() {
        return TxnDestnCode;
    }

    public void setTxnDestnCode(String TxnDestnCode) {
        this.TxnDestnCode = TxnDestnCode;
    }

    public String getTxnOrigCode() {
        return TxnOrigCode;
    }

    public void setTxnOrigCode(String TxnOrigCode) {
        this.TxnOrigCode = TxnOrigCode;
    }

    public String getDeliveryChannelCtrlID() {
        return DeliveryChannelCtrlID;
    }

    public void setDeliveryChannelCtrlID(String DeliveryChannelCtrlID) {
        this.DeliveryChannelCtrlID = DeliveryChannelCtrlID;
    }

    public PvtDataField48 getPvtDataField48() {
        return PvtDataField48;
    }

    public void setPvtDataField48(PvtDataField48 PvtDataField48) {
        this.PvtDataField48 = PvtDataField48;
    }

    public PvtDataField125 getPvtDataField125() {
        return PvtDataField125;
    }

    public void setPvtDataField125(PvtDataField125 PvtDataField125) {
        this.PvtDataField125 = PvtDataField125;
    }

    public PvtDataField126 getPvtDataField126() {
        return PvtDataField126;
    }

    public void setPvtDataField126(PvtDataField126 PvtDataField126) {
        this.PvtDataField126 = PvtDataField126;
    }

    public PvtDataField127 getPvtDataField127() {
        return PvtDataField127;
    }

    public void setPvtDataField127(PvtDataField127 PvtDataField127) {
        this.PvtDataField127 = PvtDataField127;
    }

}
