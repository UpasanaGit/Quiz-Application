/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.StringReader;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

/**
 *
 * @author test
 */
public class TestCarResponse {

    public static void main(String[] args) throws FileNotFoundException, Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\test\\Documents\\Shared\\XML\\CarResponse1.xml"));
        String str = "";
        while ((str = br.readLine()) != null) {
            sb.append(str);
        }
        CarResponse1 generatedReport = (CarResponse1) deSerialize(CarResponse1.class, sb.toString());
        System.out.println(new Gson().toJson(generatedReport));

        StringBuilder sb1 = new StringBuilder();
        BufferedReader br1 = new BufferedReader(new FileReader("C:\\Users\\test\\Documents\\Shared\\XML\\CarResponse.xml"));
        String str1 = "";
        while ((str1 = br1.readLine()) != null) {
            sb1.append(str1);
        }
        CarResponse generatedReport1 = (CarResponse) deSerialize(CarResponse.class, sb1.toString());
        System.out.println(new Gson().toJson(generatedReport1));
    }

    public static Object deSerialize(Class className, String xmlString) throws Exception {
        Serializer serializer = new Persister();
        return serializer.read(className, new StringReader(xmlString));
    }
}
