/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import java.io.Serializable;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author test
 */
@Root(name = "AccountDetail", strict = false)
public class AccountDetail  implements Serializable{

    @Element(name = "CustomerID", required = false)
    private String CustomerID = "";
    @Element(name = "AccNum", required = false)
    private String AccNum = "";
    @Element(name = "AccSeg", required = false)
    private String AccSeg = "";
    @Element(name = "AccStatus", required = false)
    private String AccStatus = "";
    @Element(name = "AcctName", required = false)
    private String AcctName = "";
    @Element(name = "MobileNo", required = false)
    private String MobileNo = "";

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getAccNum() {
        return AccNum;
    }

    public void setAccNum(String AccNum) {
        this.AccNum = AccNum;
    }

    public String getAccSeg() {
        return AccSeg;
    }

    public void setAccSeg(String AccSeg) {
        this.AccSeg = AccSeg;
    }

    public String getAccStatus() {
        return AccStatus;
    }

    public void setAccStatus(String AccStatus) {
        this.AccStatus = AccStatus;
    }

    public String getAcctName() {
        return AcctName;
    }

    public void setAcctName(String AcctName) {
        this.AcctName = AcctName;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String MobileNo) {
        this.MobileNo = MobileNo;
    }

}
