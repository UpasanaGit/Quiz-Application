/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import java.io.Serializable;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author test
 */
@Root(name = "XML", strict = false)
public class CarResponse1 implements Serializable{

    @Element(name = "MessageType", required = false)
    private String MessageType = "";
    @Element(name = "ProcCode", required = false)
    private String ProcCode = "";
    @Element(name = "STAN", required = false)
    private String STAN = "";
    @Element(name = "LocalTxnDtTime", required = false)
    private String LocalTxnDtTime = "";
    @Element(name = "ActCode", required = false)
    private String ActCode = "";
    @Element(name = "ActMsg", required = false)
    private String ActMsg = "";
    @Element(name = "FSID", required = false)
    private String FSID = "";
    @Element(name = "CUST_ID", required = false)
    private String CUST_ID = "";
    @Element(name = "ORIGINAL_NAME", required = false)
    private String ORIGINAL_NAME = "";
    @Element(name = "ACC_NO", required = false)
    private String ACC_NO = "";
    @Element(name = "SrNo", required = false)
    private String SrNo = "";
    @Element(name = "NET_USER_ID", required = false)
    private String NET_USER_ID = "";

    public String getMessageType() {
        return MessageType;
    }

    public void setMessageType(String MessageType) {
        this.MessageType = MessageType;
    }

    public String getProcCode() {
        return ProcCode;
    }

    public void setProcCode(String ProcCode) {
        this.ProcCode = ProcCode;
    }

    public String getSTAN() {
        return STAN;
    }

    public void setSTAN(String STAN) {
        this.STAN = STAN;
    }

    public String getLocalTxnDtTime() {
        return LocalTxnDtTime;
    }

    public void setLocalTxnDtTime(String LocalTxnDtTime) {
        this.LocalTxnDtTime = LocalTxnDtTime;
    }

    public String getActCode() {
        return ActCode;
    }

    public void setActCode(String ActCode) {
        this.ActCode = ActCode;
    }

    public String getActMsg() {
        return ActMsg;
    }

    public void setActMsg(String ActMsg) {
        this.ActMsg = ActMsg;
    }

    public String getFSID() {
        return FSID;
    }

    public void setFSID(String FSID) {
        this.FSID = FSID;
    }

    public String getCUST_ID() {
        return CUST_ID;
    }

    public void setCUST_ID(String CUST_ID) {
        this.CUST_ID = CUST_ID;
    }

    public String getORIGINAL_NAME() {
        return ORIGINAL_NAME;
    }

    public void setORIGINAL_NAME(String ORIGINAL_NAME) {
        this.ORIGINAL_NAME = ORIGINAL_NAME;
    }

    public String getACC_NO() {
        return ACC_NO;
    }

    public void setACC_NO(String ACC_NO) {
        this.ACC_NO = ACC_NO;
    }

    public String getSrNo() {
        return SrNo;
    }

    public void setSrNo(String SrNo) {
        this.SrNo = SrNo;
    }

    public String getNET_USER_ID() {
        return NET_USER_ID;
    }

    public void setNET_USER_ID(String NET_USER_ID) {
        this.NET_USER_ID = NET_USER_ID;
    }

}
