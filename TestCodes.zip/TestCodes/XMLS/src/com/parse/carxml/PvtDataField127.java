/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.parse.carxml;

import java.io.Serializable;
import java.util.List;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author test
 */
@Root(name = "PvtDataField127", strict = false)
public class PvtDataField127  implements Serializable{
     @Element(name = "NoOfFsId", required = false)
    private String NoOfFsId = "";
    @ElementList(entry = "FsIdDetails", inline = true, required = false)
    List<FsIdDetail> FsIdDetails;

    public String getNoOfFsId() {
        return NoOfFsId;
    }

    public void setNoOfFsId(String NoOfFsId) {
        this.NoOfFsId = NoOfFsId;
    }

    public List<FsIdDetail> getFsIdDetails() {
        return FsIdDetails;
    }

    public void setFsIdDetails(List<FsIdDetail> FsIdDetails) {
        this.FsIdDetails = FsIdDetails;
    }
}
