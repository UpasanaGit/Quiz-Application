/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hitSoapRest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

/**
 *
 * @author test
 */
public class HitSoap {

    public static void main(String[] args) throws Exception {
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        final SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        final String url = "http://192.168.1.219:7001/CalculatorWS/Calculator";
        int a = 45;
        int b = 23;
//        String requestStr = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
//                + "    <soap:Header/>\n"
//                + "    <soap:Body>\n"
//                + "        <ns1:add xmlns:ns1=\"http://calculator.me.org/\">\n"
//                + "            <a>" + a + "</a>\n"
//                + "            <b>" + b + "</b>\n"
//                + "        </ns1:add>\n"
//                + "    </soap:Body>\n"
//                + "</soap:Envelope>";

        String requestStr = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                + "    <soap:Body>\n"
                + "        <ns1:hello xmlns:ns1=\"http://calculator.me.org/\">\n"
                + "            <name> Test </name>\n"
                + "        </ns1:hello>\n"
                + "    </soap:Body>\n"
                + "</soap:Envelope>";
//        String requestStr = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
//                + "    <soap:Body>\n"
//                + "        <ns1:subtract xmlns:ns1=\"http://calculator.me.org/\">\n"
//                + "            <a>" + a + "</a>\n"
//                + "            <b>" + b + "</b>\n"
//                + "        </ns1:subtract>\n"
//                + "    </soap:Body>\n"
//                + "</soap:Envelope>";

        SOAPMessage requestSoap = null;
        InputStream is = new ByteArrayInputStream(requestStr.toString().getBytes());
        requestSoap = MessageFactory.newInstance().createMessage(null, is);

        //to add header to a request
        SOAPEnvelope envelope = requestSoap.getSOAPPart().getEnvelope();
        SOAPHeader headers = envelope.addHeader();
        SOAPHeaderElement tokenHeader = headers.addHeaderElement(new QName("http://calculator.me.org/", "token"));
        tokenHeader.setTextContent("1234");

        requestSoap.saveChanges();
        SOAPMessage soapResponse = soapConnection.call(requestSoap, url);
        System.out.println(soapMessageToString(soapResponse));
        System.out.println(soapMessageToString(requestSoap));
        soapConnection.close();
    }

    public static String soapMessageToString(SOAPMessage message) {
        String result = null;

        if (message != null) {
            ByteArrayOutputStream baos = null;
            try {
                baos = new ByteArrayOutputStream();
                message.writeTo(baos);
                result = baos.toString();
            } catch (Exception e) {
            } finally {
                if (baos != null) {
                    try {
                        baos.close();
                    } catch (IOException ioe) {
                    }
                }
            }
        }
        return result;
    }
}
