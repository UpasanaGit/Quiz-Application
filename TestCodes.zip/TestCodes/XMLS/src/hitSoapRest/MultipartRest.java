/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hitSoapRest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;

/**
 *
 * @author test
 */
public class MultipartRest {

    public static void main(String[] args) {

        String charset = "UTF-8";
        String fileName = "C:\\Users\\test\\Downloads\\download.jpg";
        String requestURL = "http://192.168.1.219:7001/TrainingProject/testRest/TestRest/uploadDoc";
        try {

            URL url = new URL(requestURL);
            HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setDoOutput(true);
            httpConn.setRequestMethod("POST");

            FileInputStream fis = new FileInputStream(new File(fileName));
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("file", new InputStreamBody(fis, new File(fileName).getName()));
            multipartEntity.addPart("fileName", new StringBody("download.jpg"));
            httpConn.setRequestProperty("Content-Type", multipartEntity.getContentType().getValue());
            OutputStream out = httpConn.getOutputStream();
            try {
                multipartEntity.writeTo(out);
            } finally {
                out.close();
            }
            if (httpConn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + httpConn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader((httpConn.getInputStream())));
            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            httpConn.disconnect();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
